# Source de Vie — système en ligne

Application web de gestion des souscriptions et versements du Comité de Construction Source de Vie.

## Déploiement Render

Le projet utilise Node.js/Express et PostgreSQL. Les mots de passe initiaux et JWT_SECRET sont fournis via les variables d’environnement Render, jamais dans le dépôt public.

Variables requises :
- `JWT_SECRET`
- `SOURCE_VIE_PW_PAUL`
- `SOURCE_VIE_PW_JEAN`
- `SOURCE_VIE_PW_VANESSA`
- `SOURCE_VIE_PW_JACQUES`
- `DATABASE_URL` est fourni automatiquement par le Blueprint Render.
