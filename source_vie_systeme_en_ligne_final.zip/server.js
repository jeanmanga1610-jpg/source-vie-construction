const express=require('express');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const {Pool}=require('pg');
const app=express();
app.use(express.json({limit:'10mb'}));

const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET) throw new Error('JWT_SECRET est obligatoire en production.');
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});

const USERS=[
 ['Paul.Mabosho','Paul Mabosho','SOURCE_VIE_PW_PAUL','editor'],
 ['Jean.Manga','Jean Manga','SOURCE_VIE_PW_JEAN','editor'],
 ['Vanessa.Jelly','Vanessa Jelly','SOURCE_VIE_PW_VANESSA','editor'],
 ['Jacques.Muchapa','Jacques Muchapa','SOURCE_VIE_PW_JACQUES','editor']
];

async function init(){
  await pool.query(`CREATE TABLE IF NOT EXISTS app_state(id integer primary key, goal numeric not null default 50000, data jsonb not null default '[]'::jsonb);`);
  await pool.query(`CREATE TABLE IF NOT EXISTS app_users(username text primary key,name text not null,password_hash text not null,must_change boolean not null default true,role text not null default 'editor');`);
  await pool.query(`CREATE TABLE IF NOT EXISTS audit(id bigserial primary key,date timestamptz not null default now(),username text,name text,action text,details text);`);
  const state=await pool.query('SELECT id FROM app_state WHERE id=1');
  if(!state.rowCount) await pool.query('INSERT INTO app_state(id,goal,data) VALUES(1,50000,\'[]\'::jsonb)');
  for(const [username,name,envKey,role] of USERS){
    const pw=process.env[envKey];
    if(!pw) continue;
    const hash=await bcrypt.hash(pw,12);
    await pool.query(`INSERT INTO app_users(username,name,password_hash,must_change,role) VALUES($1,$2,$3,true,$4) ON CONFLICT(username) DO NOTHING`,[username,name,hash,role]);
  }
}

function auth(req,res,next){
  try{
    const h=req.headers.authorization||'';
    const token=h.startsWith('Bearer ')?h.slice(7):'';
    req.user=jwt.verify(token,JWT_SECRET); next();
  }catch(e){res.status(401).json({error:'Connexion requise.'});}
}
async function audit(user,action,details){
  await pool.query('INSERT INTO audit(username,name,action,details) VALUES($1,$2,$3,$4)',[user?.username||'public',user?.name||'Consultation',action,details]);
}

app.get('/health',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true});}catch(e){res.status(503).json({ok:false});}});
app.get('/api/state',async(req,res)=>{try{const r=await pool.query('SELECT goal,data FROM app_state WHERE id=1');res.json(r.rows[0]||{goal:50000,data:[]});}catch(e){res.status(500).json({error:'Erreur serveur.'});}});

app.post('/api/login',async(req,res)=>{
  try{
    const {username,password}=req.body||{};
    const r=await pool.query('SELECT * FROM app_users WHERE username=$1',[username]);
    const u=r.rows[0];
    if(!u||!await bcrypt.compare(password||'',u.password_hash)) return res.status(401).json({error:'Identifiant ou mot de passe incorrect.'});
    const token=jwt.sign({username:u.username,name:u.name,role:u.role},JWT_SECRET,{expiresIn:'12h'});
    await audit(u,'Connexion','Connexion réussie');
    res.json({token,user:{username:u.username,name:u.name,role:u.role,mustChange:u.must_change}});
  }catch(e){res.status(500).json({error:'Erreur serveur.'});}
});

app.post('/api/password',auth,async(req,res)=>{
  try{
    const {oldPassword,newPassword}=req.body||{};
    if(!newPassword||newPassword.length<8) return res.status(400).json({error:'Le nouveau mot de passe doit contenir au moins 8 caractères.'});
    const r=await pool.query('SELECT * FROM app_users WHERE username=$1',[req.user.username]);
    const u=r.rows[0];
    if(!u||!await bcrypt.compare(oldPassword||'',u.password_hash)) return res.status(400).json({error:'Le mot de passe provisoire est incorrect.'});
    await pool.query('UPDATE app_users SET password_hash=$1,must_change=false WHERE username=$2',[await bcrypt.hash(newPassword,12),u.username]);
    await audit(req.user,'Réinitialisation du mot de passe','Mot de passe provisoire remplacé par l’utilisateur');
    res.json({ok:true});
  }catch(e){res.status(500).json({error:'Erreur serveur.'});}
});

app.put('/api/state',auth,async(req,res)=>{
  try{
    if(req.user.role!=='editor') return res.status(403).json({error:'Accès refusé.'});
    if(!Array.isArray(req.body.data)) return res.status(400).json({error:'Données invalides.'});
    const goal=typeof req.body.goal==='number'?req.body.goal:50000;
    await pool.query('UPDATE app_state SET goal=$1,data=$2 WHERE id=1',[goal,JSON.stringify(req.body.data)]);
    await audit(req.user,'Mise à jour des données','Souscripteurs et versements synchronisés');
    res.json({ok:true});
  }catch(e){res.status(500).json({error:'Erreur serveur.'});}
});

app.get('/api/audit',auth,async(req,res)=>{try{const r=await pool.query('SELECT id,date,username,name,action,details FROM audit ORDER BY date DESC LIMIT 2000');res.json(r.rows);}catch(e){res.status(500).json({error:'Erreur serveur.'});}});

app.get('*',(req,res)=>res.sendFile(require('path').join(__dirname,'index.html')));

init().then(()=>app.listen(PORT,()=>console.log('Source de Vie online on '+PORT))).catch(err=>{console.error(err);process.exit(1)});
