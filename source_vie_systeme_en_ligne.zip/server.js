const express=require('express');
const fs=require('fs'); const path=require('path'); const bcrypt=require('bcryptjs'); const jwt=require('jsonwebtoken');
const app=express(); app.use(express.json({limit:'5mb'}));
const PORT=process.env.PORT||3000; const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_ME_IN_PRODUCTION';
const DB_FILE=process.env.DATA_FILE||path.join(__dirname,'data.json');
const seedUsers=[
 ['Paul.Mabosho','Paul Mabosho','Construction@1'],['Jean.Manga','Jean Manga','Construction@2'],['Vanessa.Jelly','Vanessa Jelly','Construction@3'],['Jacques.Muchapa','Jacques Muchapa','Construction@4']
];
function load(){if(!fs.existsSync(DB_FILE)) return {goal:50000,data:[],users:seedUsers.map(([username,name,pw])=>({username,name,passwordHash:bcrypt.hashSync(pw,12),mustChange:true,role:'editor'})),audit:[]};return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}
let db=load(); function persist(){const tmp=DB_FILE+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db));fs.renameSync(tmp,DB_FILE)} if(!fs.existsSync(DB_FILE))persist();
function auth(req,res,next){try{const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):'';req.user=jwt.verify(token,JWT_SECRET);next()}catch(e){res.status(401).json({error:'Connexion requise.'})}}
function audit(user,action,details){db.audit.unshift({id:Date.now()+Math.random(),date:new Date().toISOString(),username:user?.username||'public',name:user?.name||'Consultation',action,details});db.audit=db.audit.slice(0,2000);persist()}
app.get('/api/state',(req,res)=>res.json({goal:db.goal,data:db.data}));
app.post('/api/login',(req,res)=>{const {username,password}=req.body||{};const u=db.users.find(x=>x.username===username);if(!u||!bcrypt.compareSync(password||'',u.passwordHash))return res.status(401).json({error:'Identifiant ou mot de passe incorrect.'});const token=jwt.sign({username:u.username,name:u.name,role:u.role},JWT_SECRET,{expiresIn:'12h'});audit(u,'Connexion','Connexion réussie');res.json({token,user:{username:u.username,name:u.name,role:u.role,mustChange:u.mustChange}})});
app.post('/api/password',auth,(req,res)=>{const u=db.users.find(x=>x.username===req.user.username);const {oldPassword,newPassword}=req.body||{};if(!u||!bcrypt.compareSync(oldPassword||'',u.passwordHash))return res.status(400).json({error:'Le mot de passe provisoire est incorrect.'});if(!newPassword||newPassword.length<8)return res.status(400).json({error:'Le nouveau mot de passe doit contenir au moins 8 caractères.'});u.passwordHash=bcrypt.hashSync(newPassword,12);u.mustChange=false;audit(u,'Réinitialisation du mot de passe','Mot de passe provisoire remplacé par l’utilisateur');res.json({ok:true})});
app.put('/api/state',auth,(req,res)=>{if(req.user.role!=='editor')return res.status(403).json({error:'Accès refusé.'});if(!Array.isArray(req.body.data))return res.status(400).json({error:'Données invalides.'});db.data=req.body.data; if(typeof req.body.goal==='number')db.goal=req.body.goal;audit(req.user,'Mise à jour des données','Souscripteurs et versements synchronisés');res.json({ok:true})});
app.get('/api/audit',auth,(req,res)=>res.json(db.audit));
app.get('/health',(req,res)=>res.json({ok:true}));
app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));
app.listen(PORT,()=>console.log('Source de Vie online on '+PORT));
