# Source de Vie — version en ligne

Application web avec authentification serveur, sauvegarde centralisée, journal d’audit et synchronisation des souscripteurs/versements.

## Comptes initiaux
- Paul.Mabosho / Construction@1
- Jean.Manga / Construction@2
- Vanessa.Jelly / Construction@3
- Jacques.Muchapa / Construction@4

Chaque compte doit changer son mot de passe à la première connexion.

## Lancement
```bash
npm install
JWT_SECRET="une-longue-valeur-secrete" npm start
```

L’application écoute sur le port `3000` (ou `PORT`). Les données sont conservées dans `data.json` sur le serveur. Pour un hébergement sans disque persistant, utiliser un stockage persistant ou adapter la couche de données à une base managée.

## Mise en ligne
Déployer le dossier sur un hébergeur Node.js, définir `JWT_SECRET` et activer un disque persistant pour `data.json`.
